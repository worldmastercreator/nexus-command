import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { TrophyCelebration, type TrophyPayload } from "@/components/TrophyCelebration";
import {
  Award,
  BarChart3,
  Bell,
  Castle,
  ChevronRight,
  Crown,
  FileBadge,
  Flame,
  Gem,
  Gift,
  History,
  IdCard,
  LayoutDashboard,
  Library,
  LineChart,
  Medal,
  QrCode,
  Search,
  Settings,
  Share2,
  Shield,
  Sparkles,
  Star,
  Target,
  TrendingUp,
  Trophy,
  Users,
  Zap,
} from "lucide-react";
import heroTrophy from "@/assets/hero-trophy.jpg";
import goldMedal from "@/assets/gold-medal.jpg";
import winnerBadge from "@/assets/winner-badge.jpg";
import trophies from "@/assets/trophies.jpg";

const canonicalUrl = "https://id-preview--1a9dcce9-1b10-43c0-beb9-63c65bb77bf7.lovable.app/";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AMS Dashboard — Software Vala" },
      {
        name: "description",
        content:
          "Premium executive achievement dashboard for Software Vala AMS covering passport, membership, reputation, trophies, rewards, hall of fame, and legacy.",
      },
      { property: "og:title", content: "AMS Dashboard — Software Vala" },
      {
        property: "og:description",
        content:
          "Luxury corporate award-ceremony dashboard for digital identity, recognition, achievements, ranks, and legacy.",
      },
      { property: "og:image", content: heroTrophy },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "AMS Dashboard — Software Vala" },
      {
        name: "twitter:description",
        content:
          "Executive award and achievement dashboard with passport, reputation, rank progression, and hall of fame.",
      },
      { name: "twitter:image", content: heroTrophy },
    ],
    links: [{ rel: "canonical", href: canonicalUrl }],
  }),
  component: Dashboard,
});

const sidebarSections = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: IdCard, label: "Passport Center" },
  { icon: Award, label: "Achievement Center" },
  { icon: Medal, label: "Badge Center" },
  { icon: Trophy, label: "Trophy Center" },
  { icon: Crown, label: "Rank Center" },
  { icon: Shield, label: "Membership Center" },
  { icon: Star, label: "Reputation Center" },
  { icon: Sparkles, label: "Recognition Center" },
  { icon: Gift, label: "Reward Center" },
  { icon: FileBadge, label: "Certificate Center" },
  { icon: Target, label: "Mission Center" },
  { icon: BarChart3, label: "Leaderboard Center" },
  { icon: Castle, label: "Hall Of Fame" },
  { icon: History, label: "Journey Center" },
  { icon: Library, label: "Collections Center" },
  { icon: LineChart, label: "Analytics Center" },
  { icon: Settings, label: "Settings" },
];

const executiveStats = [
  { label: "XP Earned", value: "184,290", delta: "+2,140 today", icon: Zap },
  { label: "Achievements", value: "148", delta: "12 hidden unlocked", icon: Award },
  { label: "Trophies", value: "39", delta: "Legend showcase active", icon: Trophy },
  { label: "Recognition", value: "26", delta: "Top Vendor 2026", icon: Medal },
];

const passportScores = [
  { label: "Trust Score", value: "9,842", icon: Shield },
  { label: "Reputation", value: "9,620", icon: Star },
  { label: "Contribution", value: "8,904", icon: Users },
  { label: "Influence", value: "97 / 100", icon: TrendingUp },
  { label: "Loyalty", value: "Elite", icon: Crown },
  { label: "Legacy", value: "Founder", icon: Castle },
];

const membershipTiers = ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Elite", "Founder"];
const ranks = ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Elite", "Champion", "Legend", "Immortal"];

const recentAchievements = [
  { title: "Master Contributor", tier: "Diamond", date: "2h ago", xp: 2500 },
  { title: "First 1000 Sales", tier: "Gold", date: "1d ago", xp: 1800 },
  { title: "Community Pillar", tier: "Platinum", date: "3d ago", xp: 2100 },
  { title: "Verified Mentor", tier: "Gold", date: "5d ago", xp: 1500 },
];

const missionBoard = [
  { title: "Mentor 3 community members", progress: 66, reward: "+300 XP" },
  { title: "Publish a new asset", progress: 100, reward: "Badge" },
  { title: "Reach 50 reputation today", progress: 42, reward: "+500 XP" },
  { title: "Earn one new certificate", progress: 18, reward: "Trophy" },
];

const rewards = [
  { title: "Premium License", value: "12 left", icon: Shield },
  { title: "Discount 40%", value: "Claim", icon: Sparkles },
  { title: "Elite Frame", value: "Unlocked", icon: Crown },
  { title: "Founder Pin", value: "Legendary", icon: Medal },
];

const hallOfFame = [
  { name: "Aarav Mehta", title: "Founder Circle", score: 12480 },
  { name: "Priya Sharma", title: "Top Vendor 2026", score: 11920 },
  { name: "Rohan Kapoor", title: "Lifetime Legend", score: 11540 },
  { name: "Ananya Iyer", title: "Champion Author", score: 10870 },
  { name: "Vikram Singh", title: "Elite Partner", score: 10210 },
];

const achievementModes = [
  "Achievement Builder",
  "Achievement Chains",
  "Hidden Achievements",
  "Secret Achievements",
  "Manual Achievements",
  "Automatic Achievements",
  "Achievement Analytics",
  "Achievement Vault",
];

const analytics = [
  { label: "Membership", value: 88 },
  { label: "Reputation", value: 94 },
  { label: "Achievement", value: 79 },
  { label: "Rewards", value: 72 },
  { label: "Rank", value: 91 },
  { label: "Retention", value: 84 },
];

const journey = [
  "Register",
  "Passport Created",
  "Bronze Membership",
  "Earn XP",
  "Unlock Achievement",
  "Get Badge",
  "Get Trophy",
  "Increase Reputation",
  "Rank Up",
  "Membership Upgrade",
  "Rewards",
  "Recognition",
  "Hall Of Fame",
  "Legend",
  "Immortal",
  "Legacy",
];

const aiInsights = [
  "AI Reputation Analysis suggests high-trust momentum in partner activity and community mentoring.",
  "AI Growth Suggestions recommend one certificate and two weekly missions to reach Champion this cycle.",
  "AI Membership Suggestions indicate Founder Circle retention strength with premium reward affinity above 92%.",
];

const enterpriseModules: { group: string; icon: typeof Award; items: string[] }[] = [
  {
    group: "Achievement Engine",
    icon: Award,
    items: [
      "Achievement Templates",
      "Achievement Builder",
      "Achievement Dependency",
      "Achievement Chains",
      "Secret Achievements",
      "Hidden Achievements",
      "Dynamic Achievements",
      "Auto Unlock Rules",
      "Manual Unlock Rules",
      "Achievement Approval",
      "Achievement Revocation",
    ],
  },
  {
    group: "Trophy Cabinet",
    icon: Trophy,
    items: [
      "Trophy Cabinet",
      "Trophy Showcase",
      "Trophy Categories",
      "Trophy Rarity",
      "Trophy Evolution",
    ],
  },
  {
    group: "Badge System",
    icon: Medal,
    items: ["Badge Collections", "Badge Sets", "Badge Fusion", "Badge Seasons"],
  },
  {
    group: "XP Engine",
    icon: Zap,
    items: ["XP Engine", "XP Multipliers", "XP Boosters", "XP Decay Rules"],
  },
  {
    group: "Rank Engine",
    icon: Crown,
    items: ["Rank Engine", "Rank Protection", "Rank Promotion", "Rank Demotion"],
  },
  {
    group: "Reward Engine",
    icon: Gift,
    items: ["Reward Engine", "Reward Store", "Reward Claims", "Reward Expiry"],
  },
  {
    group: "Point Economy",
    icon: Sparkles,
    items: ["Point Economy", "Point Transfer", "Point History", "Point Wallet"],
  },
  {
    group: "Missions & Quests",
    icon: Target,
    items: [
      "Daily Missions",
      "Weekly Missions",
      "Monthly Missions",
      "Custom Missions",
      "Quest System",
      "Quest Chains",
      "Quest Rewards",
    ],
  },
  {
    group: "Streak & Milestone",
    icon: Flame,
    items: [
      "Streak Engine",
      "Streak Freeze",
      "Streak Recovery",
      "Milestone Engine",
      "Journey Tracking",
    ],
  },
  {
    group: "Leaderboards & Fame",
    icon: BarChart3,
    items: [
      "Hall Of Fame",
      "Global Leaderboard",
      "Regional Leaderboard",
      "Team Leaderboard",
    ],
  },
  {
    group: "Collections & Showcase",
    icon: Library,
    items: ["Collections", "Albums", "Showcase Profiles"],
  },
  {
    group: "Feeds & Notifications",
    icon: Bell,
    items: [
      "Achievement Feed",
      "Activity Feed",
      "Achievement Notifications",
      "Reward Notifications",
      "Rank Notifications",
    ],
  },
  {
    group: "Celebration Studio",
    icon: Sparkles,
    items: ["Sound Manager", "Celebration Manager", "Animation Manager"],
  },
  {
    group: "Certificates",
    icon: FileBadge,
    items: ["Certificate Builder", "Certificate Verification"],
  },
  {
    group: "Community & Events",
    icon: Users,
    items: [
      "Referral Rewards",
      "Community Rewards",
      "Seasonal Pass",
      "Battle Pass Style System",
      "Event Rewards",
    ],
  },
  {
    group: "Analytics & Audit",
    icon: LineChart,
    items: [
      "Achievement Analytics",
      "Engagement Analytics",
      "Retention Analytics",
      "Achievement Audit Logs",
      "Reward Audit Logs",
      "XP Audit Logs",
    ],
  },
  {
    group: "Integrity & Security",
    icon: Shield,
    items: ["Anti Abuse System", "Anti Farming System", "Fraud Detection"],
  },
  {
    group: "Automation & API",
    icon: Settings,
    items: ["Rule Engine", "Automation Engine", "Achievement API", "Webhook Manager"],
  },
  {
    group: "AI Designer",
    icon: Sparkles,
    items: ["AI Achievement Designer", "AI Reward Suggestions"],
  },
];

const rarityTiers = [
  { tier: "Mythic", weight: 100, color: "from-amber-300 to-yellow-600" },
  { tier: "Legendary", weight: 80, color: "from-yellow-200 to-amber-500" },
  { tier: "Epic", weight: 60, color: "from-purple-300 to-amber-400" },
  { tier: "Rare", weight: 40, color: "from-sky-300 to-amber-300" },
  { tier: "Common", weight: 20, color: "from-zinc-300 to-zinc-500" },
];

const influenceScores = [
  { label: "Achievement Power", value: "9,840" },
  { label: "User Influence", value: "9,612" },
  { label: "Contribution", value: "8,904" },
  { label: "Loyalty", value: "9,402" },
  { label: "Consistency", value: "9,180" },
  { label: "Community", value: "8,720" },
  { label: "Collector", value: "94 / 100" },
  { label: "Completion", value: "87%" },
];

const deepModules: { group: string; icon: typeof Award; items: string[] }[] = [
  {
    group: "Prestige System",
    icon: Crown,
    items: ["Prestige System", "Prestige Levels", "Prestige Reset Rewards"],
  },
  {
    group: "Mastery & Skill",
    icon: Sparkles,
    items: [
      "Achievement DNA",
      "Achievement Tree",
      "Skill Tree",
      "Mastery System",
      "Expertise Levels",
      "Certification Path",
    ],
  },
  {
    group: "Score Architecture",
    icon: LineChart,
    items: [
      "Collector Score",
      "Completion Score",
      "Achievement Rarity Engine",
      "Achievement Weightage",
      "Achievement Power Score",
      "User Influence Score",
      "Contribution Score",
      "Loyalty Score",
      "Consistency Score",
      "Community Score",
    ],
  },
  {
    group: "Journey Tracks",
    icon: History,
    items: ["Career Journey", "Learning Journey", "Success Journey"],
  },
  {
    group: "Seasons",
    icon: Flame,
    items: [
      "Achievement Seasons",
      "Season Archives",
      "Season Champions",
      "Season Rewards",
      "Season History",
    ],
  },
  {
    group: "Elite Clubs",
    icon: Shield,
    items: ["Achievement Clubs", "Elite Clubs", "Founder Club", "VIP Club", "Achievement Auctions"],
  },
  {
    group: "Showcase Rooms",
    icon: Library,
    items: [
      "Achievement Showcase Rooms",
      "Personal Trophy Room",
      "Digital Museum",
      "Achievement Hologram Wall",
    ],
  },
  {
    group: "Ceremony & Halls",
    icon: Castle,
    items: [
      "Recognition Center",
      "Achievement Ceremony",
      "Award Events",
      "Hall Of Legends",
      "Hall Of Heroes",
    ],
  },
  {
    group: "Legacy & Memory",
    icon: Trophy,
    items: [
      "Achievement Legacy",
      "Inheritance System",
      "Achievement Time Capsule",
      "Achievement Memories Timeline",
      "Achievement Documentary",
      "Achievement Biography",
    ],
  },
  {
    group: "Portfolio & Verify",
    icon: FileBadge,
    items: [
      "Achievement Portfolio",
      "Achievement Resume Builder",
      "Achievement Verification Center",
      "Achievement Public Profile",
      "Achievement QR Verification",
    ],
  },
  {
    group: "Future Layer",
    icon: Sparkles,
    items: [
      "Achievement NFT Ready Layer",
      "Achievement Blockchain Ready Layer",
    ],
  },
  {
    group: "Universal Identity",
    icon: IdCard,
    items: [
      "Cross Product Achievement Sync",
      "Global Identity Score",
      "Universal Reputation Score",
      "Universal Achievement Passport",
    ],
  },
];

const passportWorthScores = [
  { label: "User Worth Score", value: "9,984", icon: Crown, hint: "Top 0.1% globally" },
  { label: "Influence Score", value: "9,612", icon: TrendingUp, hint: "Tier · Mythic" },
  { label: "Contribution Score", value: "9,408", icon: Users, hint: "1,284 commits" },
  { label: "Loyalty Score", value: "9,750", icon: Shield, hint: "7 yrs · Founder" },
  { label: "Trust Score", value: "9,842", icon: FileBadge, hint: "Verified Partner" },
  { label: "Activity Score", value: "9,201", icon: Flame, hint: "284 day streak" },
  { label: "Ecosystem Score", value: "9,560", icon: Castle, hint: "All Products Active" },
  { label: "Legacy Score", value: "Founder", icon: Medal, hint: "Hall Of Fame · 2024" },
];

const recognitionOfMonth = [
  { title: "Employee Of The Month", name: "Aarav Mehta", role: "Lead Architect", score: "9,940" },
  { title: "Reseller Of The Month", name: "Priya Sharma", role: "Diamond Reseller", score: "9,812" },
  { title: "Vendor Of The Month", name: "Karan Industries", role: "Platinum Vendor", score: "9,704" },
  { title: "Author Of The Month", name: "Ishita Rao", role: "Master Author", score: "9,680" },
  { title: "Partner Of The Month", name: "Nexus Cloud", role: "Strategic Partner", score: "9,612" },
];

const wallOfLegends = [
  { rank: "#1", name: "Aarav Mehta", title: "Immortal · Founder Club", points: "98,420" },
  { rank: "#2", name: "Priya Sharma", title: "Legend · Ambassador", points: "94,210" },
  { rank: "#3", name: "Karan Patel", title: "Legend · Elite Club", points: "91,840" },
  { rank: "#4", name: "Ishita Rao", title: "Champion · VIP 5", points: "88,560" },
  { rank: "#5", name: "Rohan Verma", title: "Champion · Diamond", points: "85,920" },
];

const aiReputationInsights = [
  { title: "Reputation Trajectory", detail: "+12.4% growth vs last quarter · projected Mythic tier by Q3", icon: TrendingUp },
  { title: "Suggested Achievement", detail: "Unlock 'Century Mentor' — 6 mentorships away from Diamond crown", icon: Sparkles },
  { title: "Growth Recommendation", detail: "Engage Ambassador Club to push Influence Score past 9,800", icon: LineChart },
];

const passportModules: { group: string; icon: typeof Award; items: string[] }[] = [
  {
    group: "Profile Showcase",
    icon: IdCard,
    items: ["Trophy Cabinet", "Badge Cabinet", "Certificates", "Achievements", "Awards", "Hall Of Fame Entries"],
  },
  {
    group: "Journey",
    icon: History,
    items: ["Timeline", "Milestones", "Growth Path", "Career Map", "Learning Journey"],
  },
  {
    group: "Social Graph",
    icon: Users,
    items: ["Followers", "Following", "Endorsements", "Recommendations", "Kudos", "Appreciation Notes"],
  },
  {
    group: "Premium Clubs",
    icon: Crown,
    items: ["VIP Club", "Founder Club", "Elite Club", "Ambassador Club"],
  },
  {
    group: "History Vault",
    icon: Library,
    items: ["Achievement History", "Rank History", "Reward History", "Reputation History"],
  },
  {
    group: "Special Walls",
    icon: Castle,
    items: ["Wall Of Fame", "Wall Of Legends", "Top 100", "Lifetime Achievers", "Rising Stars"],
  },
];

function Particles() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {Array.from({ length: 28 }).map((_, i) => (
        <span
          key={i}
          className="particle"
          style={{
            left: `${(i * 29) % 100}%`,
            top: `${(i * 41) % 100}%`,
            animationDelay: `${(i % 8) * 0.5}s`,
            animationDuration: `${5 + (i % 6)}s`,
            opacity: 0.24 + (i % 4) * 0.16,
          }}
        />
      ))}
    </div>
  );
}

function GoldFrame({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`gold-frame ${className}`}>{children}</div>;
}

function SectionHeading({ eyebrow, title, detail }: { eyebrow: string; title: string; detail?: string }) {
  return (
    <div className="space-y-2">
      <div className="text-[10px] tracking-[0.32em] uppercase text-gold">{eyebrow}</div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h2 className="font-display text-3xl sm:text-4xl leading-none">{title}</h2>
        {detail ? <p className="max-w-lg text-sm text-muted-foreground">{detail}</p> : null}
      </div>
    </div>
  );
}

function Dashboard() {
  const [celebration, setCelebration] = useState<TrophyPayload | null>(null);
  return (
    <div className="min-h-screen flex text-foreground">
      <TrophyCelebration payload={celebration} onClose={() => setCelebration(null)} />


      <aside className="w-72 shrink-0 border-r border-border bg-card/75 backdrop-blur-xl sticky top-0 h-screen overflow-y-auto">
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="relative h-11 w-11 rounded-md flex items-center justify-center bg-primary text-primary-foreground shadow-[var(--shadow-gold)]">
              <Crown className="h-6 w-6" />
            </div>
            <div>
              <div className="font-display text-xl gold-text leading-tight">AMS</div>
              <div className="text-[10px] tracking-[0.25em] text-muted-foreground uppercase">Software Vala</div>
            </div>
          </div>
          <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
            Digital identity, reputation, recognition, membership, achievement, and legacy engine.
          </p>
        </div>

        <nav className="p-3 space-y-1.5">
          {sidebarSections.map((section) => (
            <button
              key={section.label}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all ${
                section.active
                  ? "bg-primary text-primary-foreground shadow-[var(--shadow-gold)]"
                  : "text-muted-foreground hover:text-gold hover:bg-primary/8"
              }`}
            >
              <section.icon className="h-4 w-4" />
              <span className="flex-1 text-left">{section.label}</span>
              {section.active ? <ChevronRight className="h-3.5 w-3.5" /> : null}
            </button>
          ))}
        </nav>
      </aside>

      <main className="flex-1 min-w-0">
        <header className="sticky top-0 z-20 border-b border-border bg-background/85 backdrop-blur-xl">
          <div className="flex flex-wrap items-center gap-4 px-6 py-4 lg:px-8">
            <div className="relative flex-1 min-w-[240px] max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                placeholder="Search passport, achievements, membership..."
                className="w-full rounded-md border border-border bg-card/60 py-2.5 pl-10 pr-4 text-sm text-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div className="ml-auto flex items-center gap-3">
              <button className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-card/60 hover:bg-primary/8" aria-label="Notifications">
                <Bell className="h-4 w-4 text-gold" />
              </button>
              <button className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground shadow-[var(--shadow-gold)]">
                <Share2 className="h-4 w-4" />
                <span>Share Passport</span>
              </button>
            </div>
          </div>
        </header>

        <div className="px-6 py-6 lg:px-8 lg:py-8 space-y-8">
          <section className="section-award hero-band overflow-hidden">
            <Particles />
            <div className="grid gap-8 xl:grid-cols-[1.2fr_0.8fr] xl:items-center">
              <div className="space-y-6 relative z-10">
                <div className="inline-flex items-center gap-2 rounded-full gold-border px-3 py-1 text-xs uppercase tracking-[0.24em] text-gold">
                  <Sparkles className="h-3.5 w-3.5" />
                  Luxury Corporate Award Theme
                </div>

                <div className="space-y-4">
                  <h1 className="font-display text-5xl leading-none sm:text-6xl xl:text-7xl">
                    Achievement
                    <br />
                    <span className="shimmer">Management System</span>
                  </h1>
                  <p className="max-w-2xl text-base leading-7 text-muted-foreground sm:text-lg">
                    AMS is the Digital Identity, Reputation, Recognition, Membership, Achievement,
                    and Legacy Engine of the entire Software Vala ecosystem.
                  </p>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  {[
                    { label: "Membership", value: "Founder Circle" },
                    { label: "Current Rank", value: "Legend" },
                    { label: "Hall Of Fame", value: "#04 Global" },
                  ].map((item) => (
                    <div key={item.label} className="rounded-md border border-border bg-card/55 px-4 py-4 backdrop-blur-md">
                      <div className="text-[10px] uppercase tracking-[0.24em] text-muted-foreground">{item.label}</div>
                      <div className="mt-2 font-display text-2xl gold-text">{item.value}</div>
                    </div>
                  ))}
                </div>

                <GoldFrame>
                  <div className="grid gap-6 lg:grid-cols-[auto_1fr_auto] lg:items-center">
                    <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary text-3xl font-display text-primary-foreground shadow-[var(--shadow-gold)]">
                      A
                    </div>
                    <div>
                      <div className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground">Passport Center · Public & Private Identity</div>
                      <div className="mt-1 font-display text-3xl">Aarav Mehta</div>
                      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <span className="rounded-full gold-border px-3 py-1 text-gold">Founder Membership</span>
                        <span>Rank · Legend</span>
                        <span>Level 87</span>
                        <span>XP 184,290</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-center rounded-md border border-border bg-card/60 p-3">
                      <QrCode className="h-12 w-12 text-gold" />
                    </div>
                  </div>
                </GoldFrame>
              </div>

              <GoldFrame className="relative overflow-hidden p-0">
                <div className="hero-visual min-h-[420px]">
                  <img
                    src={heroTrophy}
                    alt="Executive gold trophy centerpiece for the AMS award dashboard"
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                    <div className="text-[10px] uppercase tracking-[0.34em] text-gold">Trophy Center Spotlight</div>
                    <div className="mt-2 font-display text-3xl sm:text-4xl">Champion of Champions</div>
                    <p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">
                      Premium gold trophy presentation with award-stage lighting, ceremonial framing, and legacy emphasis.
                    </p>
                  </div>
                </div>
              </GoldFrame>
            </div>
          </section>

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {executiveStats.map((stat) => (
              <article key={stat.label} className="card-luxe p-6">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-[10px] uppercase tracking-[0.28em] text-muted-foreground">{stat.label}</div>
                    <div className="mt-3 font-display text-4xl gold-text">{stat.value}</div>
                    <div className="mt-2 text-xs text-gold/85">{stat.delta}</div>
                  </div>
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-md gold-border bg-primary/8">
                    <stat.icon className="h-5 w-5 text-gold" />
                  </div>
                </div>
              </article>
            ))}
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Passport Center"
              title="Digital Identity Command"
              detail="Executive passport, score architecture, rank progression, and membership intelligence unified in one award-led command surface."
            />

            <div className="mt-8 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
              <article className="card-luxe p-6 sm:p-8">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Passport Overview</div>
                    <h3 className="mt-2 font-display text-3xl">Identity, Reputation & Legacy</h3>
                  </div>
                  <button className="inline-flex items-center gap-2 rounded-md gold-border px-3 py-2 text-xs uppercase tracking-[0.24em] text-gold">
                    <QrCode className="h-3.5 w-3.5" />
                    Public Passport
                  </button>
                </div>

                <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {passportScores.map((score) => (
                    <div key={score.label} className="rounded-md border border-border bg-card/50 p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div className="text-[10px] uppercase tracking-[0.24em] text-muted-foreground">{score.label}</div>
                        <score.icon className="h-4 w-4 text-gold" />
                      </div>
                      <div className="mt-3 font-display text-2xl gold-text">{score.value}</div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
                  <div className="rounded-md border border-border bg-card/45 p-5">
                    <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Membership Center</div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {membershipTiers.map((tier, index) => (
                        <span
                          key={tier}
                          className={`rounded-full px-3 py-1 text-xs uppercase tracking-[0.2em] ${
                            index >= 4 ? "gold-border text-gold" : "border border-border text-muted-foreground"
                          }`}
                        >
                          {tier}
                        </span>
                      ))}
                    </div>
                    <div className="mt-5 text-sm leading-6 text-muted-foreground">
                      Founder membership is active with premium benefits, upgrade history, analytics, and ceremonial profile privileges enabled.
                    </div>
                  </div>

                  <div className="rounded-md border border-border bg-card/45 p-5">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Rank Center</div>
                        <div className="mt-1 font-display text-2xl">Path to Immortal</div>
                      </div>
                      <div className="text-right text-xs text-muted-foreground">
                        <div>Next rank in</div>
                        <div className="mt-1 font-display text-xl gold-text">12,420 XP</div>
                      </div>
                    </div>

                    <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-secondary">
                      <div className="h-full w-[83%] bg-primary" />
                    </div>

                    <div className="mt-5 grid grid-cols-3 gap-3 sm:grid-cols-9">
                      {ranks.map((rank, index) => {
                        const reached = index <= 7;
                        const current = index === 7;
                        return (
                          <div key={rank} className="text-center">
                            <div
                              className={`mx-auto flex h-10 w-10 items-center justify-center rounded-full border ${
                                reached ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card/60 text-muted-foreground"
                              } ${current ? "shadow-[var(--shadow-gold)]" : ""}`}
                            >
                              <Crown className="h-4 w-4" />
                            </div>
                            <div className={`mt-2 text-[10px] uppercase tracking-[0.18em] ${current ? "text-gold" : "text-muted-foreground"}`}>
                              {rank}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </article>

              <article className="card-luxe overflow-hidden">
                <div className="grid h-full md:grid-cols-[0.9fr_1.1fr] xl:grid-cols-1">
                  <div className="relative min-h-[260px] xl:min-h-[320px]">
                    <img
                      src={trophies}
                      alt="Gold trophy collection gallery for the AMS trophy center"
                      className="h-full w-full object-cover"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                    <div className="absolute left-5 top-5 rounded-full gold-border px-3 py-1 text-[10px] uppercase tracking-[0.28em] text-gold">
                      Trophy Room
                    </div>
                  </div>

                  <div className="p-6 sm:p-8">
                    <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Collections Center</div>
                    <h3 className="mt-2 font-display text-3xl">Trophy Showcase & Museum</h3>
                    <p className="mt-3 text-sm leading-6 text-muted-foreground">
                      Bronze to Founder trophies arranged as a ceremonial collection wall with gallery, showcase, and museum styling.
                    </p>

                    <div className="mt-6 grid grid-cols-3 gap-3">
                      {["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Elite", "Champion", "Legend", "Founder"].map((tier, index) => (
                        <div key={tier} className="rounded-md border border-border bg-card/45 px-2 py-3 text-center">
                          <Trophy className={`mx-auto h-5 w-5 ${index >= 2 ? "text-gold" : "text-muted-foreground"}`} />
                          <div className="mt-2 text-[9px] uppercase tracking-[0.18em] text-muted-foreground">{tier}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </article>
            </div>
          </section>

          <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr_0.8fr]">
            <article className="card-luxe p-6 sm:p-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Achievement Center</div>
                  <h3 className="mt-2 font-display text-3xl">Achievement Builder & Vault</h3>
                </div>
                <Award className="h-5 w-5 text-gold" />
              </div>

              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                {achievementModes.map((mode) => (
                  <div key={mode} className="rounded-md border border-border bg-card/50 px-4 py-4 text-sm text-foreground">
                    {mode}
                  </div>
                ))}
              </div>

              <div className="mt-6 space-y-3">
                {recentAchievements.map((achievement) => (
                  <div key={achievement.title} className="flex items-center gap-3 rounded-md border border-border bg-card/45 p-3">
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-gold">
                      <Flame className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{achievement.title}</div>
                      <div className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
                        {achievement.tier} · {achievement.date}
                      </div>
                    </div>
                    <div className="text-xs gold-text">+{achievement.xp} XP</div>
                  </div>
                ))}
              </div>
            </article>

            <article className="card-luxe overflow-hidden">
              <img
                src={winnerBadge}
                alt="Luxury gold winner badge for the recognition and badge center"
                className="aspect-[4/5] w-full object-cover"
                loading="lazy"
              />
              <div className="p-6">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Badge Center</div>
                <h3 className="mt-2 font-display text-3xl">Recognition Badge Showcase</h3>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">
                  Premium gold badges, rarity sets, curated collections, and corporate winner-mark visuals aligned with the award-ceremony reference style.
                </p>
              </div>
            </article>

            <article className="card-luxe overflow-hidden">
              <img
                src={goldMedal}
                alt="Executive gold medal artwork for membership and recognition spotlight"
                className="aspect-[4/5] w-full object-cover"
                loading="lazy"
              />
              <div className="p-6">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Recognition Center</div>
                <h3 className="mt-2 font-display text-3xl">Medal & Honor Spotlight</h3>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">
                  Employee of the Month, Top Contributor, Founder Circle, and partner honors presented with premium medal framing.
                </p>
              </div>
            </article>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Leaderboard & Hall Of Fame"
              title="Recognition, Rewards & Public Status"
              detail="Seasonal ranking, ceremonial status display, reward wallet, and mission momentum presented with boardroom polish rather than gaming language."
            />

            <div className="mt-8 grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
              <article className="card-luxe p-6 sm:p-8">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Hall Of Fame</div>
                    <h3 className="mt-2 font-display text-3xl">Top 100 · This Season</h3>
                  </div>
                  <button className="rounded-full gold-border px-3 py-1.5 text-xs uppercase tracking-[0.2em] text-gold">
                    View All
                  </button>
                </div>

                <div className="mt-6 space-y-2">
                  {hallOfFame.map((person, index) => (
                    <div key={person.name} className="grid grid-cols-[44px_1fr_auto_auto] items-center gap-4 rounded-md border border-border bg-card/50 p-4">
                      <div className={`flex h-11 w-11 items-center justify-center rounded-full font-display text-lg ${index < 3 ? "bg-primary text-primary-foreground shadow-[var(--shadow-gold)]" : "gold-border text-gold"}`}>
                        {index + 1}
                      </div>
                      <div>
                        <div className="text-sm font-medium">{person.name}</div>
                        <div className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">{person.title}</div>
                      </div>
                      <div className="hidden gap-1 sm:flex">
                        {Array.from({ length: 5 }).map((_, starIndex) => (
                          <Star key={starIndex} className={`h-3.5 w-3.5 ${starIndex < 5 - (index % 2) ? "fill-gold text-gold" : "text-muted-foreground"}`} />
                        ))}
                      </div>
                      <div className="font-display text-xl gold-text tabular-nums">{person.score.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </article>

              <div className="grid gap-6">
                <article className="card-luxe p-6 sm:p-8">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Mission Center</div>
                      <h3 className="mt-2 font-display text-3xl">Daily & Season Missions</h3>
                    </div>
                    <Target className="h-5 w-5 text-gold" />
                  </div>

                  <div className="mt-6 space-y-5">
                    {missionBoard.map((mission) => (
                      <div key={mission.title}>
                        <div className="mb-2 flex items-center justify-between gap-4 text-sm">
                          <span>{mission.title}</span>
                          <span className="text-xs uppercase tracking-[0.14em] text-gold">{mission.reward}</span>
                        </div>
                        <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                          <div className="h-full bg-primary" style={{ width: `${mission.progress}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </article>

                <article className="card-luxe p-6 sm:p-8">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Reward Center</div>
                      <h3 className="mt-2 font-display text-3xl">VIP Reward Wallet</h3>
                    </div>
                    <Gift className="h-5 w-5 text-gold" />
                  </div>

                  <div className="mt-6 grid grid-cols-2 gap-4">
                    {rewards.map((reward) => (
                      <div key={reward.title} className="rounded-md border border-border bg-card/45 p-4">
                        <reward.icon className="h-6 w-6 text-gold" />
                        <div className="mt-4 text-sm font-medium">{reward.title}</div>
                        <div className="mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground">{reward.value}</div>
                      </div>
                    ))}
                  </div>
                </article>
              </div>
            </div>
          </section>

          <section className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
            <article className="card-luxe p-6 sm:p-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-gold">AI Features</div>
                  <h3 className="mt-2 font-display text-3xl">Growth Intelligence</h3>
                </div>
                <Sparkles className="h-5 w-5 text-gold" />
              </div>

              <div className="mt-6 space-y-4">
                {aiInsights.map((insight) => (
                  <div key={insight} className="rounded-md border border-border bg-card/50 p-4 text-sm leading-6 text-muted-foreground">
                    {insight}
                  </div>
                ))}
              </div>
            </article>

            <article className="card-luxe p-6 sm:p-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Analytics Center</div>
                  <h3 className="mt-2 font-display text-3xl">Membership, Trust & Retention</h3>
                </div>
                <BarChart3 className="h-5 w-5 text-gold" />
              </div>

              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                {analytics.map((metric) => (
                  <div key={metric.label} className="rounded-md border border-border bg-card/45 p-4">
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <span>{metric.label} Analytics</span>
                      <span className="gold-text">{metric.value}%</span>
                    </div>
                    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-secondary">
                      <div className="h-full bg-primary" style={{ width: `${metric.value}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </article>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Journey Center"
              title="From Passport To Legacy"
              detail="A clear executive recognition lifecycle showing identity creation, progressive reputation, trophy unlocks, reward upgrades, and immortal legacy status."
            />

            <div className="mt-8 grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Journey Timeline</div>
                <div className="mt-6 space-y-5">
                  {journey.slice(0, 8).map((step, index) => (
                    <div key={step} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground shadow-[var(--shadow-gold)]">
                          {index + 1}
                        </div>
                        {index < 7 ? <div className="mt-2 h-full w-px bg-border" /> : null}
                      </div>
                      <div className="pb-4">
                        <div className="font-display text-2xl leading-none">{step}</div>
                        <div className="mt-2 text-sm leading-6 text-muted-foreground">
                          Reputation, recognition, badges, trophies, and membership benefits progress in one verified legacy timeline.
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </article>

              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Final User Flow</div>
                <div className="mt-5 flex flex-wrap gap-3">
                  {journey.map((step, index) => (
                    <div key={step} className="flex items-center gap-3">
                      <div className="rounded-full border border-border bg-card/55 px-4 py-2 text-xs uppercase tracking-[0.18em] text-foreground">
                        {step}
                      </div>
                      {index < journey.length - 1 ? <ChevronRight className="h-4 w-4 text-gold" /> : null}
                    </div>
                  ))}
                </div>
              </article>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Enterprise Modules"
              title="Complete AMS Capability Matrix"
              detail="Every engine, rule set, automation, and intelligence layer that powers the Software Vala AMS — presented as a ceremonial capability cabinet."
            />

            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {enterpriseModules.map((module) => (
                <article key={module.group} className="card-luxe p-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Module</div>
                      <h3 className="mt-1 font-display text-2xl leading-tight">{module.group}</h3>
                    </div>
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/8">
                      <module.icon className="h-4.5 w-4.5 text-gold" />
                    </div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {module.items.map((item) => (
                      <span
                        key={item}
                        className="rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] tracking-[0.08em] text-foreground/85 hover:text-gold hover:border-primary/40 transition"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Celebration Studio · Trial Mode"
              title="Trophy Unlock · Full Ceremony Sequence"
              detail="Screen dim → trophy burst → gold light → confetti → particles → sound → rank up → reward reveal → share → save to trophy room."
            />
            <div className="mt-8 card-luxe p-6 sm:p-8">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                {([
                  { tier: "bronze", title: "First Purchase", subtitle: "Soft Bell · 60Hz Buzz", xp: 250, reward: "10% Off", icon: Medal },
                  { tier: "silver", title: "10 Reviews Written", subtitle: "Crystal Chime", xp: 600, reward: "Free Plugin", rankUp: { from: "Bronze", to: "Silver" }, icon: Medal },
                  { tier: "gold", title: "Top Reseller", subtitle: "Victory Fanfare", xp: 1500, reward: "VIP 2 Badge", rankUp: { from: "Silver", to: "Gold" }, icon: Trophy },
                  { tier: "diamond", title: "100 Sales", subtitle: "Epic Orchestra + AI Voice", xp: 5000, reward: "Diamond Frame", rankUp: { from: "Gold", to: "Diamond" }, icon: Gem },
                  { tier: "legend", title: "Hall Of Fame", subtitle: "Cinematic + Crowd Cheer + Fireworks", xp: 25000, reward: "Founder Crown", rankUp: { from: "Champion", to: "Legend" }, icon: Crown },
                ] as Array<TrophyPayload & { icon: typeof Trophy }>).map((p) => (
                  <button
                    key={p.tier}
                    type="button"
                    onClick={() => setCelebration(p)}
                    className="group rounded-md gold-border bg-card/60 p-5 text-left transition hover:bg-primary/10 hover:scale-[1.02]"
                  >
                    <p.icon className="h-7 w-7 text-gold" />
                    <div className="mt-3 text-[10px] uppercase tracking-[0.28em] text-gold">{p.tier}</div>
                    <div className="mt-1 font-display text-lg leading-tight">{p.title}</div>
                    <div className="mt-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{p.subtitle}</div>
                    <div className="mt-4 text-xs text-foreground/70">Tap to trigger ceremony →</div>
                  </button>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Screen Dim</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Gold Light Burst</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Confetti</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Particle Effects</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Trophy Rotate</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Slow Zoom</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Achievement Sound</span>
                <span className="rounded-full border border-border bg-card/50 px-3 py-1">Mobile Vibration</span>
                <span className="rounded-full gold-border bg-primary/10 px-3 py-1 text-gold">Fireworks · Diamond+</span>
                <span className="rounded-full gold-border bg-primary/10 px-3 py-1 text-gold">AI Voice · Legend</span>
              </div>
            </div>
          </section>


          <section className="section-award">
            <SectionHeading
              eyebrow="AMS Master Flow"
              title="Register → Passport → Legacy · 16 Stages"
              detail="Every user moves through the same pipeline — from first signup to permanent legend status."
            />

            <div className="mt-8 card-luxe p-6 sm:p-10">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  { n: "01", step: "Register", icon: IdCard },
                  { n: "02", step: "Passport Created", icon: QrCode },
                  { n: "03", step: "Bronze Membership", icon: Medal },
                  { n: "04", step: "Earn Points", icon: Zap },
                  { n: "05", step: "Gain XP", icon: TrendingUp },
                  { n: "06", step: "Unlock Achievement", icon: Trophy },
                  { n: "07", step: "Get Badge", icon: Award },
                  { n: "08", step: "Increase Reputation", icon: Star },
                  { n: "09", step: "Increase Trust", icon: Shield },
                  { n: "10", step: "Level Up", icon: BarChart3 },
                  { n: "11", step: "Rank Up", icon: ChevronRight },
                  { n: "12", step: "Get Rewards", icon: Gift },
                  { n: "13", step: "Get Recognition", icon: Sparkles },
                  { n: "14", step: "Hall Of Fame", icon: Castle },
                  { n: "15", step: "Legend Status", icon: Crown },
                  { n: "16", step: "Legacy", icon: Library },
                ].map((s) => (
                  <div key={s.n} className="rounded-md gold-border bg-card/60 p-4 flex items-center gap-3">
                    <div className="font-display text-2xl gold-text w-10">{s.n}</div>
                    <div className="inline-flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                      <s.icon className="h-4 w-4 text-gold" />
                    </div>
                    <div className="text-sm font-medium">{s.step}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="AMS Rules Engine"
              title="The Laws of Reputation, Reward & Legacy"
              detail="Immutable laws that govern every score, badge, and rank change across the ecosystem."
            />

            <div className="mt-8 grid gap-6 lg:grid-cols-2">
              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Earn Rules</div>
                <h3 className="mt-2 font-display text-2xl">How Status Is Built</h3>
                <ul className="mt-5 space-y-2 text-sm">
                  {[
                    "Every action gives points",
                    "Every point gives XP",
                    "XP increases level",
                    "Level unlocks rank",
                    "Rank unlocks membership",
                    "Membership unlocks benefits",
                    "Achievements unlock badges",
                    "Badges increase reputation",
                    "Reputation increases trust",
                    "Trust unlocks special access",
                  ].map((r) => (
                    <li key={r} className="flex items-start gap-3 rounded-md border border-border bg-card/40 px-4 py-2">
                      <ChevronRight className="h-4 w-4 text-gold mt-0.5 shrink-0" />
                      <span className="text-foreground/85">{r}</span>
                    </li>
                  ))}
                </ul>
              </article>

              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Integrity & Legacy Rules</div>
                <h3 className="mt-2 font-display text-2xl">What Can Never Be Bought</h3>
                <ul className="mt-5 space-y-2 text-sm">
                  {[
                    "Rewards never reduce reputation",
                    "Fraud reduces reputation",
                    "Abuse reduces trust",
                    "Inactive users lose activity score",
                    "Hall Of Fame is earned, not purchased",
                    "Founder status cannot be purchased",
                    "Legacy status is permanent",
                    "Every achievement logged forever",
                    "Every reward logged forever",
                    "Every rank change logged forever",
                  ].map((r) => (
                    <li key={r} className="flex items-start gap-3 rounded-md gold-border bg-primary/5 px-4 py-2">
                      <Shield className="h-4 w-4 text-gold mt-0.5 shrink-0" />
                      <span className="text-foreground/90">{r}</span>
                    </li>
                  ))}
                </ul>
              </article>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="The Main Formula"
              title="AMS Score = Activity + Contribution + Loyalty + Trust + Achievements"
              detail="One universal score that decides Rank, Membership, Recognition, Hall Of Fame, and VIP Status."
            />

            <div className="mt-8 card-luxe p-6 sm:p-10 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-transparent to-primary/5 pointer-events-none" />
              <div className="relative">
                <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
                  {[
                    { label: "Activity", icon: Flame },
                    { label: "Contribution", icon: Users },
                    { label: "Loyalty", icon: Crown },
                    { label: "Trust", icon: Shield },
                    { label: "Achievements", icon: Trophy },
                  ].map((f, i, arr) => (
                    <div key={f.label} className="flex items-center gap-3 sm:gap-4">
                      <div className="rounded-md gold-border bg-card/70 px-5 py-4 text-center min-w-[120px]">
                        <f.icon className="mx-auto h-5 w-5 text-gold" />
                        <div className="mt-2 text-[10px] uppercase tracking-[0.22em] text-gold">{f.label}</div>
                      </div>
                      {i < arr.length - 1 && <span className="font-display text-3xl gold-text">+</span>}
                    </div>
                  ))}
                  <span className="font-display text-3xl gold-text">=</span>
                  <div className="rounded-md gold-border bg-primary/15 px-6 py-5 text-center min-w-[160px]">
                    <Crown className="mx-auto h-6 w-6 text-gold" />
                    <div className="mt-2 text-[10px] uppercase tracking-[0.28em] text-gold">AMS Score</div>
                    <div className="mt-1 font-display text-2xl gold-text">9,840</div>
                  </div>
                </div>

                <div className="mt-10">
                  <div className="text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground">AMS Score Decides</div>
                  <div className="mt-4 grid gap-3 sm:grid-cols-5">
                    {[
                      { k: "Rank", icon: TrendingUp },
                      { k: "Membership", icon: Medal },
                      { k: "Recognition", icon: Award },
                      { k: "Hall Of Fame", icon: Castle },
                      { k: "VIP Status", icon: Crown },
                    ].map((d) => (
                      <div key={d.k} className="rounded-md border border-border bg-card/60 p-4 text-center">
                        <d.icon className="mx-auto h-5 w-5 text-gold" />
                        <div className="mt-2 text-xs uppercase tracking-[0.2em] text-foreground/85">{d.k}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>


          <section className="section-award">
            <SectionHeading
              eyebrow="AMS Philosophy"
              title="User Manager vs AMS — Status & Recognition Engine"
              detail="User Manager kehta hai &quot;Ye user hai.&quot; AMS kehta hai &quot;Ye user kitna valuable hai.&quot;"
            />

            <div className="mt-8 grid gap-6 lg:grid-cols-2">
              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">User Manager</div>
                <h3 className="mt-2 font-display text-3xl">"Ye user hai."</h3>
                <p className="mt-3 text-sm text-foreground/70">Stores identity. Stores profile. Stores login. Nothing else.</p>
                <div className="mt-6 space-y-2 text-sm">
                  {["Name", "Email", "Password", "Profile Picture", "Phone"].map((x) => (
                    <div key={x} className="rounded-md border border-border bg-card/40 px-4 py-2 text-foreground/70">{x}</div>
                  ))}
                </div>
              </article>

              <article className="card-luxe p-6 sm:p-8 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent pointer-events-none" />
                <div className="relative">
                  <div className="text-[10px] uppercase tracking-[0.3em] text-gold">AMS · Software Vala</div>
                  <h3 className="mt-2 font-display text-3xl gold-text">"Ye user kitna valuable hai."</h3>
                  <p className="mt-3 text-sm text-foreground/80">Measures worth. Tracks legacy. Recognises every contribution.</p>
                  <div className="mt-6 grid grid-cols-2 gap-2 text-xs">
                    {["Rank", "Reputation", "Trust", "Achievements", "Badges", "Rewards", "VIP Status", "Hall Of Fame", "Legacy"].map((x) => (
                      <div key={x} className="rounded-md gold-border bg-primary/8 px-3 py-2 text-gold uppercase tracking-[0.18em]">{x}</div>
                    ))}
                  </div>
                </div>
              </article>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="AMS Main Flow"
              title="Identity → Points → Achievements → Legacy"
              detail="The ten-stage value engine — every user moves through this pipeline from register to immortal legend."
            />

            <div className="mt-8 card-luxe p-6 sm:p-10">
              <div className="flex flex-wrap items-center justify-center gap-3">
                {[
                  { step: "Identity", icon: IdCard },
                  { step: "Points", icon: Zap },
                  { step: "Achievements", icon: Trophy },
                  { step: "Badges", icon: Medal },
                  { step: "Ranks", icon: TrendingUp },
                  { step: "Rewards", icon: Gift },
                  { step: "Recognition", icon: Award },
                  { step: "Reputation", icon: Star },
                  { step: "Status", icon: Crown },
                  { step: "Legacy", icon: Castle },
                ].map((s, i, arr) => (
                  <div key={s.step} className="flex items-center gap-3">
                    <div className="flex flex-col items-center gap-2 min-w-[88px]">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full gold-border bg-primary/10">
                        <s.icon className="h-5 w-5 text-gold" />
                      </div>
                      <div className="text-[10px] uppercase tracking-[0.22em] text-foreground/80">{s.step}</div>
                    </div>
                    {i < arr.length - 1 && <ChevronRight className="h-4 w-4 text-gold/60" />}
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Career Journey"
              title="Joined → Customer → Power User → VIP → Champion → Legend"
              detail="Lifecycle progression in the Software Vala ecosystem."
            />
            <div className="mt-8 grid gap-6 md:grid-cols-2">
              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Rank Ladder</div>
                <h3 className="mt-2 font-display text-2xl">Normal User → Legend</h3>
                <div className="mt-6 space-y-3">
                  {["Normal User", "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Champion", "Grand Champion", "Legend"].map((r, i) => (
                    <div key={r} className="flex items-center gap-4">
                      <span className="w-8 font-display text-lg gold-text">{String(i + 1).padStart(2, "0")}</span>
                      <div className="flex-1 rounded-md border border-border bg-card/50 px-4 py-2 text-sm">{r}</div>
                    </div>
                  ))}
                </div>
              </article>

              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Career Lifecycle</div>
                <h3 className="mt-2 font-display text-2xl">Joined → Legend</h3>
                <div className="mt-6 space-y-3">
                  {[
                    { stage: "Joined", note: "Registered · Profile Built" },
                    { stage: "Customer", note: "First Purchase · Verified Buyer" },
                    { stage: "Power User", note: "Active · 10+ Achievements" },
                    { stage: "VIP", note: "VIP 1 → VIP 5 · Premium Access" },
                    { stage: "Champion", note: "Top Reseller / Vendor / Author" },
                    { stage: "Legend", note: "Hall Of Fame · Lifetime Legacy" },
                  ].map((s) => (
                    <div key={s.stage} className="rounded-md gold-border bg-primary/5 p-4">
                      <div className="font-display text-lg gold-text">{s.stage}</div>
                      <div className="text-[11px] uppercase tracking-[0.18em] text-foreground/70 mt-1">{s.note}</div>
                    </div>
                  ))}
                </div>
              </article>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Example Pathways"
              title="Real Achievement, Reward & Reputation Loops"
              detail="How everyday actions translate into status across the ecosystem."
            />
            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {[
                {
                  group: "Achievement Examples",
                  icon: Trophy,
                  items: ["First Purchase", "10 Purchases", "100 Purchases", "Top Reviewer", "Top Reseller", "Top Author", "Top Vendor", "Top Influencer", "Community Hero", "Software Expert"],
                },
                {
                  group: "Rewards Catalog",
                  icon: Gift,
                  items: ["Discount", "Free Software", "VIP Badge", "Early Access", "Premium Support", "Special Recognition"],
                },
                {
                  group: "Reputation Loop",
                  icon: Shield,
                  items: ["Good Work → Reputation Up", "Cheat / Abuse → Reputation Down", "Verified Behaviour → Trust Boost", "Community Reports → Audit", "Consistent Quality → Mythic Tier"],
                },
                {
                  group: "Hall Of Fame",
                  icon: Castle,
                  items: ["Top Reseller", "Top Vendor", "Top Author", "Top Customer", "Top Influencer", "Top Contributor"],
                },
                {
                  group: "Season System",
                  icon: Flame,
                  items: ["Season 1 · 2 · 3", "Missions Per Season", "Season Rewards", "Season Leaderboards", "Season Winners"],
                },
                {
                  group: "Mission System",
                  icon: Target,
                  items: ["Buy Software", "Write Review", "Refer Friend", "Complete Profile", "Attend Demo", "Earn Points"],
                },
                {
                  group: "Certificate System",
                  icon: FileBadge,
                  items: ["Certified Reseller", "Certified Vendor", "Certified Author", "Certified Partner"],
                },
                {
                  group: "VIP System",
                  icon: Crown,
                  items: ["VIP 1", "VIP 2", "VIP 3", "VIP 4", "VIP 5"],
                },
                {
                  group: "Trust System",
                  icon: Shield,
                  items: ["Verified User", "Verified Buyer", "Verified Partner", "Verified Reseller", "Verified Vendor"],
                },
              ].map((m) => (
                <article key={m.group} className="card-luxe p-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Pathway</div>
                      <h3 className="mt-1 font-display text-xl leading-tight">{m.group}</h3>
                    </div>
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/8">
                      <m.icon className="h-4.5 w-4.5 text-gold" />
                    </div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {m.items.map((item) => (
                      <span key={item} className="rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] tracking-[0.08em] text-foreground/85 hover:text-gold hover:border-primary/40 transition">
                        {item}
                      </span>
                    ))}
                  </div>
                </article>
              ))}
            </div>

            <div className="mt-8 card-luxe p-6 sm:p-8 text-center">
              <Sparkles className="mx-auto h-6 w-6 text-gold" />
              <h3 className="mt-3 font-display text-2xl gold-text">"Status & Recognition Engine"</h3>
              <p className="mt-2 text-sm text-foreground/75 max-w-2xl mx-auto">
                Har user ki digital reputation, achievements, ranks, rewards, status aur legacy ko manage karna. Ye sirf badge manager nahi — ye ecosystem ka recognition engine hai.
              </p>
            </div>
          </section>


          <section className="section-award">
            <SectionHeading
              eyebrow="User Passport · All In One"
              title="The Universal Achievement Passport"
              detail="LinkedIn + Achievement System + Gaming Rank — every score, every honor, every legacy artifact on a single executive screen."
            />

            <div className="mt-8 card-luxe p-6 sm:p-10 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-primary/5 pointer-events-none" />
              <div className="relative grid gap-8 lg:grid-cols-[1fr_1.4fr]">
                <div>
                  <div className="flex items-center gap-4">
                    <GoldFrame className="h-20 w-20 rounded-full">
                      <img src={winnerBadge} alt="Passport holder" className="h-full w-full object-cover rounded-full" />
                    </GoldFrame>
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Founder · VIP 5</div>
                      <h3 className="font-display text-3xl">Aarav Mehta</h3>
                      <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Immortal Rank · Hall Of Fame 2024</div>
                    </div>
                  </div>
                  <div className="mt-6 grid grid-cols-2 gap-3 text-xs">
                    {[
                      { k: "Rank", v: "Immortal" },
                      { k: "Reputation", v: "9,842" },
                      { k: "Trust", v: "Verified Partner" },
                      { k: "VIP Status", v: "Founder Club" },
                      { k: "Achievements", v: "284" },
                      { k: "Badges", v: "612" },
                      { k: "Certificates", v: "47" },
                      { k: "Hall Of Fame", v: "3 Years" },
                    ].map((row) => (
                      <div key={row.k} className="rounded-md border border-border bg-card/50 p-3">
                        <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{row.k}</div>
                        <div className="mt-1 font-display text-base gold-text">{row.v}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 flex items-center gap-3">
                    <span className="inline-flex items-center gap-2 rounded-full gold-border bg-primary/10 px-4 py-1.5 text-[10px] uppercase tracking-[0.28em] text-gold">
                      <QrCode className="h-3 w-3" /> Passport QR Verified
                    </span>
                    <span className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-1.5 text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                      NFT Ready Layer
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {passportWorthScores.map((s) => (
                    <div key={s.label} className="rounded-md gold-border bg-card/60 p-4">
                      <div className="flex items-center justify-between">
                        <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{s.label}</div>
                        <s.icon className="h-3.5 w-3.5 text-gold" />
                      </div>
                      <div className="mt-2 font-display text-2xl gold-text">{s.value}</div>
                      <div className="mt-1 text-[10px] uppercase tracking-[0.18em] text-foreground/60">{s.hint}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Recognition Of The Month"
              title="Executive Honors · December 2026"
              detail="Monthly award ceremony spotlights — Employee, Reseller, Vendor, Author, and Partner Of The Month."
            />
            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {recognitionOfMonth.map((r) => (
                <article key={r.title} className="card-luxe p-6 text-center">
                  <Trophy className="mx-auto h-8 w-8 text-gold" />
                  <div className="mt-3 text-[10px] uppercase tracking-[0.3em] text-gold">{r.title}</div>
                  <h3 className="mt-2 font-display text-2xl">{r.name}</h3>
                  <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{r.role}</div>
                  <div className="mt-4 inline-flex items-center gap-2 rounded-full gold-border bg-primary/10 px-4 py-1.5 text-[10px] uppercase tracking-[0.25em] text-gold">
                    Score · {r.score}
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Wall Of Legends"
              title="Top 100 · Lifetime Achievers · Rising Stars"
              detail="The eternal leaderboard of immortal contributors across the Software Vala ecosystem."
            />
            <div className="mt-8 card-luxe p-6 sm:p-8">
              <div className="divide-y divide-border">
                {wallOfLegends.map((l) => (
                  <div key={l.rank} className="flex items-center justify-between py-4">
                    <div className="flex items-center gap-4">
                      <span className="font-display text-3xl gold-text w-14">{l.rank}</span>
                      <div>
                        <div className="font-display text-xl">{l.name}</div>
                        <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{l.title}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Lifetime Points</div>
                      <div className="font-display text-2xl gold-text">{l.points}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="AI Reputation Intelligence"
              title="AI Insights · Suggestions · Growth"
              detail="Machine-curated reputation analysis, achievement suggestions, and personalized growth pathways."
            />
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {aiReputationInsights.map((a) => (
                <article key={a.title} className="card-luxe p-6">
                  <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/10">
                    <a.icon className="h-4.5 w-4.5 text-gold" />
                  </div>
                  <h3 className="mt-4 font-display text-xl">{a.title}</h3>
                  <p className="mt-2 text-sm text-foreground/75 leading-relaxed">{a.detail}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Passport Modules"
              title="Profile · Journey · Social · Premium · History · Walls"
              detail="Every passport surface organized into executive cabinets."
            />
            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {passportModules.map((module) => (
                <article key={module.group} className="card-luxe p-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Cabinet</div>
                      <h3 className="mt-1 font-display text-2xl leading-tight">{module.group}</h3>
                    </div>
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/8">
                      <module.icon className="h-4.5 w-4.5 text-gold" />
                    </div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {module.items.map((item) => (
                      <span
                        key={item}
                        className="rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] tracking-[0.08em] text-foreground/85 hover:text-gold hover:border-primary/40 transition"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          </section>


          <section className="section-award">
            <SectionHeading
              eyebrow="Rarity Engine"
              title="Mythic to Common · Power Weightage"
              detail="Premium rarity ladder fuels achievement power scores, influence weighting, and prestige progression across the AMS ecosystem."
            />

            <div className="mt-8 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Rarity Ladder</div>
                <div className="mt-6 space-y-4">
                  {rarityTiers.map((r) => (
                    <div key={r.tier}>
                      <div className="mb-2 flex items-center justify-between text-sm">
                        <span className="font-display text-xl">{r.tier}</span>
                        <span className="text-xs uppercase tracking-[0.18em] text-gold">Weight · {r.weight}</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-secondary">
                        <div className={`h-full bg-gradient-to-r ${r.color}`} style={{ width: `${r.weight}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </article>

              <article className="card-luxe p-6 sm:p-8">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Influence Scores</div>
                <h3 className="mt-2 font-display text-3xl">Universal Reputation Matrix</h3>
                <div className="mt-6 grid grid-cols-2 gap-3">
                  {influenceScores.map((s) => (
                    <div key={s.label} className="rounded-md border border-border bg-card/50 p-4">
                      <div className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">{s.label}</div>
                      <div className="mt-2 font-display text-2xl gold-text">{s.value}</div>
                    </div>
                  ))}
                </div>
              </article>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="Ultra Premium Modules"
              title="Prestige, Legacy & Universal Identity"
              detail="Future-proof AMS layers: prestige resets, achievement DNA, mastery trees, ceremony halls, time capsules, and the universal achievement passport."
            />

            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {deepModules.map((module) => (
                <article key={module.group} className="card-luxe p-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Layer</div>
                      <h3 className="mt-1 font-display text-2xl leading-tight">{module.group}</h3>
                    </div>
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/8">
                      <module.icon className="h-4.5 w-4.5 text-gold" />
                    </div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {module.items.map((item) => (
                      <span
                        key={item}
                        className="rounded-full border border-border bg-card/50 px-3 py-1 text-[11px] tracking-[0.08em] text-foreground/85 hover:text-gold hover:border-primary/40 transition"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="AMS Master Blueprint"
              title="Digital Identity · Reputation · Recognition · Legacy Engine"
              detail="Software Vala AMS is not a badge manager. It is the complete identity, trust, achievement, status and legacy platform for the entire ecosystem."
            />

            <div className="mt-8 grid gap-5 lg:grid-cols-3">
              <article className="card-luxe p-6 lg:col-span-2">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Core Pillars</div>
                <h3 className="mt-1 font-display text-2xl">18 Foundational Pillars</h3>
                <div className="mt-5 flex flex-wrap gap-2">
                  {["Passport","Identity","Membership","Reputation","Trust","Influence","Contribution","Loyalty","Achievements","Badges","Trophies","Ranks","Rewards","Certificates","Recognition","Leaderboards","Hall Of Fame","Legacy"].map((p) => (
                    <span key={p} className="rounded-full gold-border bg-primary/8 px-3 py-1 text-[11px] tracking-[0.06em] text-foreground/90">{p}</span>
                  ))}
                </div>
              </article>
              <article className="card-luxe p-6">
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Final Destination</div>
                <h3 className="mt-1 font-display text-2xl">User → Legacy</h3>
                <div className="mt-5 space-y-1.5 text-sm">
                  {["User","Customer","Power User","VIP","Champion","Legend","Immortal","Legacy"].map((s, i, arr) => (
                    <div key={s} className="flex items-center gap-2">
                      <span className="text-gold font-display w-6">{String(i+1).padStart(2,"0")}</span>
                      <span className={i === arr.length - 1 ? "text-gold font-medium" : "text-foreground/85"}>{s}</span>
                    </div>
                  ))}
                </div>
              </article>
            </div>

            <div className="mt-6 card-luxe p-6">
              <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Extended User Journey</div>
              <div className="mt-4 flex flex-wrap items-center gap-x-2 gap-y-3 text-sm">
                {["Register","Passport Created","Membership","Points","XP","Achievements","Badges","Reputation","Trust","Rank","Rewards","Recognition","Hall Of Fame","Legend","Immortal","Legacy"].map((s, i, arr) => (
                  <span key={s} className="inline-flex items-center gap-2">
                    <span className="rounded-md gold-border bg-card/60 px-3 py-1.5 text-foreground/90">{s}</span>
                    {i < arr.length - 1 && <ChevronRight className="h-3.5 w-3.5 text-gold/70" />}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {[
                { title: "Main Engines", icon: Settings, items: ["Passport","Identity","Membership","XP","Achievement","Badge","Trophy","Rank","Reputation","Trust","Reward","Mission","Quest","Streak","Recognition","Hall Of Fame","Legacy","Analytics","AI","Anti-Fraud"] },
                { title: "Scoring Layer", icon: BarChart3, items: ["AMS Score","Trust","Reputation","Influence","Contribution","Loyalty","Activity","Ecosystem","Authority","Expertise","Leadership","Innovation","Wisdom","Impact","Legacy","Personal Brand","Power","User Worth"] },
                { title: "Achievement Layer", icon: Trophy, items: ["Templates","Builder","Chains","Dependencies","Secret","Hidden","Dynamic","DNA","Tree","Story Mode","Timeline","Archive","Verification"] },
                { title: "Badge Layer", icon: Award, items: ["Library","Collections","Sets","Fusion","Seasons","Rarity","Showcase"] },
                { title: "Trophy Layer", icon: Gem, items: ["Cabinet","Room","Museum","Timeline","Showcase","Evolution","Insurance","Recovery"] },
                { title: "Rank Layer", icon: TrendingUp, items: ["Bronze","Silver","Gold","Platinum","Diamond","Elite","Champion","Grand Champion","Legend","Immortal"] },
                { title: "Membership Layer", icon: Crown, items: ["Bronze","Silver","Gold","Platinum","Diamond","Elite","Founder"] },
                { title: "Recognition Layer", icon: Sparkles, items: ["Employee Of Month","Reseller Of Month","Vendor Of Month","Author Of Month","Partner Of Month","Community Hero","Software Expert","People's Choice","Founder Choice"] },
                { title: "Reputation Layer", icon: Star, items: ["Trust","Credibility","Endorsements","Recommendations","Kudos","Appreciations","Salutes"] },
                { title: "Leaderboards", icon: LineChart, items: ["Global","Country","State","City","Company","Team","Reseller","Vendor","Author","Customer"] },
                { title: "Halls", icon: Castle, items: ["Hall Of Fame","Hall Of Legends","Hall Of Heroes","Hall Of Mentors","Hall Of Innovators","Hall Of Founders","Hall Of Titans"] },
                { title: "Legacy Layer", icon: Library, items: ["Legacy Vault","Time Capsule","Memory Vault","Personal Museum","Digital Statue","Digital Monument","Legacy Page","Lifetime Stats","Immortality Vault"] },
                { title: "AI Layer", icon: Flame, items: ["Achievement Suggestions","Reputation Analysis","Growth Coach","Mentor","Career Advisor","Reward Suggestions","Generated Challenges","Generated Events"] },
                { title: "Enterprise Layer", icon: Users, items: ["Team Achievements","Department Achievements","Company Achievements","Org Rankings","Achievement API","Webhooks","Automation","Rule Engine","Audit Logs"] },
                { title: "Analytics Layer", icon: LineChart, items: ["Achievement","Reputation","Trust","Engagement","Retention","Motivation","Drop-Off","AMS Health Dashboard"] },
                { title: "Protection Layer", icon: Shield, items: ["Anti Abuse","Anti Farming","Fraud Detection","Achievement Revocation","Reputation Penalties","Trust Penalties"] },
                { title: "Passport · Central Screen", icon: IdCard, items: ["Rank","Membership","Reputation","Trust","XP","Achievements","Badges","Trophies","Certificates","Rewards","Hall Of Fame","Journey","Legacy","VIP Status"] },
              ].map((layer) => (
                <article key={layer.title} className="card-luxe p-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Layer</div>
                      <h3 className="mt-1 font-display text-xl leading-tight">{layer.title}</h3>
                    </div>
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/8">
                      <layer.icon className="h-4 w-4 text-gold" />
                    </div>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {layer.items.map((it) => (
                      <span key={it} className="rounded-full border border-border bg-card/50 px-2.5 py-1 text-[10.5px] tracking-[0.05em] text-foreground/85 hover:text-gold hover:border-primary/40 transition">{it}</span>
                    ))}
                  </div>
                </article>
              ))}
            </div>

            <div className="mt-8 gold-frame">
              <div>
                <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Final Philosophy</div>
                <h3 className="mt-2 font-display text-3xl">AMS is the ecosystem's identity & legacy operating system.</h3>
                <p className="mt-3 text-sm text-foreground/80 max-w-3xl">
                  Not a badge manager. AMS manages every user's <span className="text-gold">Digital Identity</span>, <span className="text-gold">Professional Reputation</span>, <span className="text-gold">Community Recognition</span>, <span className="text-gold">Achievement History</span>, <span className="text-gold">Trust Level</span>, <span className="text-gold">Ecosystem Value</span>, and <span className="text-gold">Permanent Legacy</span> — turning users into champions, legends, and immortals.
                </p>
              </div>
            </div>
          </section>

          <section className="section-award">
            <SectionHeading
              eyebrow="AMS Enterprise Extension · v2"
              title="Governance · Compliance · Intelligence · Civilization Layers"
              detail="The final 5% — enterprise-grade governance, organizational identity, cross-product universality, predictive intelligence, and civilization-scale impact scoring."
            />

            <div className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {[
                { title: "Governance Center", icon: Shield, items: ["Achievement Policies","Reputation Policies","Trust Policies","Membership Policies","Appeals Center","Dispute Resolution","Moderation Center","Governance Council"] },
                { title: "Compliance Center", icon: FileBadge, items: ["Consent History","Data Retention Rules","Achievement Audit Compliance","Verification Compliance","Certificate Compliance"] },
                { title: "Reputation Risk Center", icon: Bell, items: ["Risk Score","Abuse Risk Score","Fraud Risk Score","Reputation Recovery Plan","Trust Recovery Plan"] },
                { title: "Relationship Center", icon: Users, items: ["Mentor Network","Student Network","Partner Network","Referral Network Graph","Influence Graph"] },
                { title: "Organization Layer", icon: Castle, items: ["Company Passport","Team Passport","Department Passport","Organization Reputation","Organization Legacy"] },
                { title: "Knowledge Layer", icon: Library, items: ["Learning Paths","Skill Verification","Competency Matrix","Expertise Verification","Knowledge Contributions"] },
                { title: "Economic Layer", icon: Gift, items: ["Ecosystem Credits","Contribution Credits","Reward Economy Analytics","Reputation Economy Analytics"] },
                { title: "Global Identity Layer", icon: QrCode, items: ["Universal Passport","Cross-Product Reputation","Cross-Product Achievements","Cross-Product Trust","Universal User Timeline"] },
                { title: "Legacy Preservation", icon: Library, items: ["Legacy Executor","Successor Assignment","Archive Preservation Rules","Historical Snapshots","Legacy Milestones"] },
                { title: "Intelligence Layer", icon: Flame, items: ["Reputation Forecast","Trust Forecast","Influence Forecast","Hall Of Fame Prediction","Achievement Prediction"] },
                { title: "Search & Discovery", icon: Search, items: ["Global User Search","Achievement Discovery","Expert Discovery","Mentor Discovery","Legend Discovery"] },
                { title: "Communication Layer", icon: Share2, items: ["Recognition Feed","Achievement Broadcasts","Community Announcements","Hall Of Fame Announcements","Founder Announcements"] },
                { title: "Ecosystem Maps", icon: LineChart, items: ["Trust Network Map","Influence Network Map","Contribution Network Map","Ecosystem Relationship Map"] },
                { title: "Digital Assets", icon: IdCard, items: ["Achievement Cards","Reputation Cards","Legacy Cards","Passport Cards","Shareable Public Profiles"] },
              ].map((layer) => (
                <article key={layer.title} className="card-luxe p-6">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-[0.28em] text-gold">Layer</div>
                      <h3 className="mt-1 font-display text-xl leading-tight">{layer.title}</h3>
                    </div>
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-md gold-border bg-primary/8">
                      <layer.icon className="h-4 w-4 text-gold" />
                    </div>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {layer.items.map((it) => (
                      <span key={it} className="rounded-full border border-border bg-card/50 px-2.5 py-1 text-[10.5px] tracking-[0.05em] text-foreground/85 hover:text-gold hover:border-primary/40 transition">{it}</span>
                    ))}
                  </div>
                </article>
              ))}
            </div>

            <div className="mt-8 gold-frame">
              <div>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-gold">Ultimate Final Layer</div>
                    <h3 className="mt-2 font-display text-3xl">Civilization-Scale Impact Scoring</h3>
                  </div>
                  <Crown className="h-10 w-10 text-gold" />
                </div>
                <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                  {[
                    { label: "Civilization Score", value: "9,840" },
                    { label: "Ecosystem Impact", value: "8,720" },
                    { label: "Generational Legacy", value: "7,650" },
                    { label: "Founder Impact", value: "9,200" },
                    { label: "Historical Importance", value: "8,410" },
                  ].map((s) => (
                    <div key={s.label} className="rounded-md gold-border bg-card/60 p-4 text-center">
                      <div className="font-display text-3xl gold-text">{s.value}</div>
                      <div className="mt-1 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{s.label}</div>
                    </div>
                  ))}
                </div>
                <p className="mt-5 text-sm text-foreground/80 max-w-3xl">
                  At this tier AMS stops measuring users — it measures their <span className="text-gold">impact on the ecosystem, the industry, and history itself</span>. Founders, immortals, and generational legends are ranked here.
                </p>
              </div>
            </div>
          </section>





          <footer className="py-8 text-center">


            <div className="gold-divider mb-6" />
            <div className="text-[10px] uppercase tracking-[0.4em] text-muted-foreground">
              Powered By <span className="text-gold">Software Vala AMS</span> · Enterprise Recognition System
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}
