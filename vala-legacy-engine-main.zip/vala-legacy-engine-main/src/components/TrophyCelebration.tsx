import { useEffect, useMemo, useState } from "react";
import { Crown, Gem, Medal, Share2, Sparkles, Trophy, X } from "lucide-react";

export type TrophyTier = "bronze" | "silver" | "gold" | "diamond" | "legend";

export interface TrophyPayload {
  tier: TrophyTier;
  title: string;
  subtitle?: string;
  xp?: number;
  reward?: string;
  rankUp?: { from: string; to: string };
}

const TIER_META: Record<TrophyTier, { label: string; color: string; glow: string; sound: string; freq: number[]; icon: typeof Trophy }> = {
  bronze: { label: "Bronze", color: "from-amber-700 to-amber-500", glow: "shadow-[0_0_60px_rgba(217,119,6,0.6)]", sound: "Soft Bell", freq: [523, 659], icon: Medal },
  silver: { label: "Silver", color: "from-slate-400 to-slate-200", glow: "shadow-[0_0_70px_rgba(203,213,225,0.7)]", sound: "Crystal Chime", freq: [659, 784, 988], icon: Medal },
  gold: { label: "Gold", color: "from-yellow-500 to-amber-300", glow: "shadow-[0_0_90px_rgba(250,204,21,0.85)]", sound: "Victory Fanfare", freq: [523, 659, 784, 1047], icon: Trophy },
  diamond: { label: "Diamond", color: "from-cyan-300 via-sky-200 to-white", glow: "shadow-[0_0_120px_rgba(125,211,252,0.9)]", sound: "Epic Orchestra Hit", freq: [392, 523, 659, 784, 1047], icon: Gem },
  legend: { label: "Legend", color: "from-amber-300 via-yellow-200 to-amber-500", glow: "shadow-[0_0_140px_rgba(252,211,77,1)]", sound: "Cinematic + Crowd Cheer", freq: [261, 329, 392, 523, 659, 784], icon: Crown },
};

function playSound(tier: TrophyTier) {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const meta = TIER_META[tier];
    meta.freq.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = tier === "legend" || tier === "diamond" ? "sawtooth" : "sine";
      osc.frequency.value = f;
      gain.gain.setValueAtTime(0, ctx.currentTime + i * 0.12);
      gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + i * 0.12 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.9);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + i * 0.12);
      osc.stop(ctx.currentTime + i * 0.12 + 1);
    });
    if ("vibrate" in navigator) {
      navigator.vibrate(tier === "legend" ? [80, 50, 120, 50, 200] : [60, 40, 80]);
    }
  } catch {
    /* audio blocked */
  }
}

function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 80 }).map((_, i) => ({
        left: Math.random() * 100,
        delay: Math.random() * 1.2,
        duration: 2.5 + Math.random() * 2,
        color: ["#FFD700", "#FFA500", "#FFF8DC", "#DAA520", "#FFFFFF"][i % 5],
        rotate: Math.random() * 360,
      })),
    [],
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {pieces.map((p, i) => (
        <span
          key={i}
          className="confetti-piece"
          style={{
            left: `${p.left}%`,
            background: p.color,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            transform: `rotate(${p.rotate}deg)`,
          }}
        />
      ))}
    </div>
  );
}

function Fireworks() {
  const bursts = useMemo(
    () =>
      Array.from({ length: 6 }).map((_, i) => ({
        left: 10 + Math.random() * 80,
        top: 10 + Math.random() * 60,
        delay: i * 0.4,
      })),
    [],
  );
  return (
    <div className="pointer-events-none absolute inset-0">
      {bursts.map((b, i) => (
        <span
          key={i}
          className="absolute h-3 w-3 rounded-full"
          style={{
            left: `${b.left}%`,
            top: `${b.top}%`,
            background: "radial-gradient(circle, #fff8dc, #ffd700, transparent)",
            boxShadow: "0 0 40px #ffd700",
            animation: `gold-burst 1.6s ease-out ${b.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

export function TrophyCelebration({ payload, onClose }: { payload: TrophyPayload | null; onClose: () => void }) {
  const [stage, setStage] = useState(0);

  useEffect(() => {
    if (!payload) return;
    setStage(0);
    playSound(payload.tier);
    const t1 = setTimeout(() => setStage(1), 900);
    const t2 = setTimeout(() => setStage(2), 1800);
    const t3 = setTimeout(() => setStage(3), 2600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [payload]);

  if (!payload) return null;
  const meta = TIER_META[payload.tier];
  const Icon = meta.icon;
  const isSpecial = payload.tier === "diamond" || payload.tier === "legend";

  return (
    <div className="celebration-overlay flex items-center justify-center" role="dialog" aria-modal="true">
      <div className="celebration-spotlight" />
      <div className="celebration-burst" />
      <div className="celebration-ring" />
      <div className="celebration-ring" style={{ animationDelay: "0.3s" }} />
      <Confetti />
      {isSpecial && <Fireworks />}

      <button
        type="button"
        onClick={onClose}
        className="absolute top-6 right-6 z-10 inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-black/40 text-white/80 hover:text-white"
        aria-label="Close celebration"
      >
        <X className="h-4 w-4" />
      </button>

      <div className="relative z-10 mx-auto max-w-lg px-6 text-center">
        <div className="text-[10px] uppercase tracking-[0.4em] text-amber-200" style={{ animation: "rise-fade 0.6s ease-out" }}>
          Achievement Unlocked · {meta.label}
        </div>

        <div className="mt-8 flex justify-center">
          <div className={`celebration-trophy relative inline-flex h-44 w-44 items-center justify-center rounded-full bg-gradient-to-br ${meta.color} ${meta.glow}`}>
            <Icon className="h-24 w-24 text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.8)]" />
            <Sparkles className="absolute -top-2 -right-2 h-6 w-6 text-amber-100 animate-pulse" />
          </div>
        </div>

        <h2 className="mt-10 font-display text-5xl text-amber-100 drop-shadow-[0_0_30px_rgba(252,211,77,0.6)]" style={{ animation: "rise-fade 0.8s ease-out 0.4s both" }}>
          {payload.title}
        </h2>
        {payload.subtitle && (
          <p className="mt-3 text-sm uppercase tracking-[0.3em] text-amber-200/80" style={{ animation: "rise-fade 0.8s ease-out 0.6s both" }}>
            {payload.subtitle}
          </p>
        )}

        {stage >= 1 && payload.rankUp && (
          <div className="mt-8 inline-flex items-center gap-3 rounded-full border border-amber-300/40 bg-amber-500/10 px-6 py-2 text-amber-100" style={{ animation: "rise-fade 0.6s ease-out" }}>
            <span className="text-xs uppercase tracking-[0.3em]">Rank Up</span>
            <span className="font-display text-lg">{payload.rankUp.from}</span>
            <span className="text-amber-300">→</span>
            <span className="font-display text-xl text-amber-200">{payload.rankUp.to}</span>
          </div>
        )}

        {stage >= 2 && (payload.reward || payload.xp) && (
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3" style={{ animation: "rise-fade 0.6s ease-out" }}>
            {payload.xp && (
              <span className="rounded-full border border-amber-300/40 bg-black/40 px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-amber-200">
                +{payload.xp.toLocaleString()} XP
              </span>
            )}
            {payload.reward && (
              <span className="rounded-full border border-amber-300/40 bg-black/40 px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-amber-200">
                Reward · {payload.reward}
              </span>
            )}
          </div>
        )}

        {isSpecial && stage >= 2 && (
          <div className="mt-4 text-[10px] uppercase tracking-[0.4em] text-amber-200/70" style={{ animation: "rise-fade 0.6s ease-out" }}>
            🎙 AI Voice · "Congratulations, Champion."
          </div>
        )}

        {stage >= 3 && (
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3" style={{ animation: "rise-fade 0.6s ease-out" }}>
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-500 to-yellow-300 px-6 py-2.5 text-sm font-medium uppercase tracking-[0.2em] text-black hover:brightness-110"
              onClick={onClose}
            >
              <Trophy className="h-4 w-4" /> Save To Trophy Room
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-2 rounded-full border border-amber-300/50 bg-black/40 px-6 py-2.5 text-sm uppercase tracking-[0.2em] text-amber-100 hover:bg-amber-500/10"
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: payload.title, text: `I just unlocked ${payload.title}!` }).catch(() => {});
                }
              }}
            >
              <Share2 className="h-4 w-4" /> Share
            </button>
          </div>
        )}

        <div className="mt-6 text-[10px] uppercase tracking-[0.3em] text-amber-200/50">
          🔊 {meta.sound} · 📳 Vibration · ✨ Spotlight
        </div>
      </div>
    </div>
  );
}
